----------------------------------------------------------------
	PROJECT 3 README
----------------------------------------------------------------
Quick overview of what is in the project:

*.vhdl           	---> Source code VHDL files (5 in total)
	add4.vhdl
	dlx_register.vhdl
	mux.vhdl
	regfile.vhdl
	sign_extend.vhdl

*.do			---> Files used for testing
	add4.do
	dlx_register.do
	mux.do
	regfile.do
	sign_extend.do


Folder: Screenshots     ---> All the screenshots of the test waves are saved here 

Folder: Work		---> Normal project folder that contains the packages